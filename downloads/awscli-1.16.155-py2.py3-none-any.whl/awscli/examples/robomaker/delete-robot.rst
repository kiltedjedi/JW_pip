**To delete a robot**

This example deletes a robot.

Command::

   aws robomaker delete-robot --robot arn:aws:robomaker:us-west-2:111111111111:robot/MyRobot/1540829698778
