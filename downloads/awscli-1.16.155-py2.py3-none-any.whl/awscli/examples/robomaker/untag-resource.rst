**To untag a resource**

This example removes a tag from a resource. It removes the Region tag.

Command::

   aws robomaker untag-resource --resource-arn "arn:aws:robomaker:us-west-2:111111111111:robot/MyRobot/1544035373264" --tag-keys Region
