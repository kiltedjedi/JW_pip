**To cancel a simulation job**

This example cancels a simulation job. 

Command::

   aws robomaker cancel-simulation-job arn:aws:robomaker:us-west-2:111111111111:simulation-job/sim-66bbb3gpxm8x

Output::

