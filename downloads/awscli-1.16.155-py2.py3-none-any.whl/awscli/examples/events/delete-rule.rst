**To delete a CloudWatch Events rule**

This example deletes the rule named EC2InstanceStateChanges::

  aws events delete-rule --name "EC2InstanceStateChanges"
