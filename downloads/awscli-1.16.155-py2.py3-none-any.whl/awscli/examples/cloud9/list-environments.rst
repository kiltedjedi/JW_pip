**To get a list of available AWS Cloud9 development environment identifiers**

This example gets a list of available AWS Cloud9 development environment identifiers.

Command::

  aws cloud9 list-environments

Output::

  {
    "environmentIds": [
      "685f892f431b45c2b28cb69eadcdb0EX",
      "1980b80e5f584920801c09086667f0EX"
    ]
  }