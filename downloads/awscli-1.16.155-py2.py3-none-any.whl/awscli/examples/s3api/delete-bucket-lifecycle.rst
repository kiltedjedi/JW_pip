The following command deletes a lifecycle configuration from a bucket named ``my-bucket``::

  aws s3api delete-bucket-lifecycle --bucket my-bucket
